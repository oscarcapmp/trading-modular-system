# El bot ahora está modularizado en:
# - infra_futuros.py
# - operacion.py
# - tacticas_entrada.py
# - tacticas_salida.py
# - bot_futuros_main.py (punto de entrada)

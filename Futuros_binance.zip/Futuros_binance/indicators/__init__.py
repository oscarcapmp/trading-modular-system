# Paquete de indicadores simples (WMAs, etc.).
